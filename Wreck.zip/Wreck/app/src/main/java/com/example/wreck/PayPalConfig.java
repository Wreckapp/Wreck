package com.example.wreck;

class PayPalConfig {
    public static final Object PAYPAL_CLIENT_ID = 1;

    public class PAYPAL_CLIENT_ID {
    }
}
